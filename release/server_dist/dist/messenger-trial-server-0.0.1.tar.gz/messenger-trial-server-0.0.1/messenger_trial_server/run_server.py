from messenger_trial_server.server.services import Server


def main():
    test_variable = Server()
    test_variable.run()


if __name__ == '__main__':
    main()
